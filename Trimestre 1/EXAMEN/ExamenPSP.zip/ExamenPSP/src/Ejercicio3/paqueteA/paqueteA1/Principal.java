package Ejercicio3.paqueteA.paqueteA1;

import java.io.*;
import java.sql.SQLOutput;

public class Principal {
    public static void main(String[] args) {
        BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
        String entradaTeclado= null;
        do {
            System.out.println("Escribe un valor mayor que cero ");
            try {
                entradaTeclado = teclado.readLine();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }while(Integer.parseInt(entradaTeclado) < 0);


        File ruta = new File("./out/production/ExamenPSP");
        ProcessBuilder pb = new ProcessBuilder("java","Ejercicio3.paqueteA.paqueteA1.HallarArea","asdf");
/**
 * SI CAMBIAS LA LINEA DE ARRIBA POR ESTA SALTARÁ UN ERROR DA IGUAL EL NUMERO QUE INTRODUZCAS
 *
        ProcessBuilder pb = new ProcessBuilder("java","Ejercicio3.paqueteA.paqueteA1.HallarArea","asdf");

 */
        pb.directory(ruta);
        Process p = null;
        try {
            p = pb.start();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }


        try{
            BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String linea;
            while ((linea = br.readLine()) != null){
                System.out.println(linea);
            }
            // Leer los posibles errores (si los hay)
            BufferedReader errorReader = new BufferedReader(new InputStreamReader(p.getErrorStream()));
            String errorLine;
            while ((errorLine = errorReader.readLine()) != null) {
                /** CON ESTA LINEA TE MUESTRA LO QUE ESCRIBE COMO SI
                 * FUERA UN ERROR ( EN COLOR ROJO ) LO DEJE EN BLANCO PARA QUE SE NOTE
                 * QUE CONTROLO EL ERROR DEL OTRO LADO
                 * System.err.println(errorLine);
                 */

                System.out.println(errorLine);
            }

            // Esperar a que el proceso termine y obtener su código de salida
            int exitCode = p.waitFor();
            System.out.println("Código de salida: " + exitCode);

        }catch (IOException e){
            System.out.println("Error del tipo IOE");
        } catch (InterruptedException e) {
            System.out.println("Error en el wait For");
        }
    }
}





package Ejercicio3.paqueteA.paqueteA1;


public class HallarArea {
    public static void main(String[] args) {
        int radio = Integer.parseInt(args[0]);
        System.out.println(radio*radio*Math.PI);
    }
}

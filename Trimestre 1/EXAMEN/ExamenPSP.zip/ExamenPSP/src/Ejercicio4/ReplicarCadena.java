package Ejercicio4;

public class ReplicarCadena {
    public static void main(String[] args) {
        String cadenaParaPrintear = args[0];
        int numeroRepeticiones = Integer.parseInt(args[1]);
        if(args.length < 2) System.exit(1);
        if (numeroRepeticiones > 0){
            for (int i = 0; i < numeroRepeticiones; i++) {
                System.out.println((i+1) +" . " + cadenaParaPrintear);
            }
        }

       if (args.length < 2){
           System.exit(1);
       }else{
           try{
               int numero = Integer.parseInt(args[1]);
               try{
                   int cadena = Integer.parseInt(args[0]);
               }catch (NumberFormatException e){
                   System.exit(0);
               }
           } catch (NumberFormatException e) {
               System.exit(2);
           }

       }
        System.exit(2);

    }
}

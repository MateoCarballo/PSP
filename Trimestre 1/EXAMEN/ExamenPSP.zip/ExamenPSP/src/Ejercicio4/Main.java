package Ejercicio4;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {
    public static void main(String[] args) throws IOException {
        File ruta = new File("./out/production/ExamenPSP");
        String cadenaReplicada = "cadena" ;
        ProcessBuilder pb = new ProcessBuilder("java","Ejercicio4/ReplicarCadena",cadenaReplicada,"10");
        //out/production/ExamenPSP/Ejercicio4/ReplicarCadena.class
        pb.directory(ruta);
        Process p = null;
        try {
            p = pb.start();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        try{
            BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String linea;
            while ((linea = br.readLine()) != null){
                System.out.println(linea);
            }
            // Leer los posibles errores (si los hay)
            BufferedReader errorReader = new BufferedReader(new InputStreamReader(p.getErrorStream()));
            String errorLine;
            while ((errorLine = errorReader.readLine()) != null) {
                System.err.println(errorLine);  // Mostrar los errores
            }

            // Esperar a que el proceso termine y obtener su código de salida
            int exitCode = p.waitFor();
            switch (exitCode){
                case 0 -> System.out.println("Salida correcta la cadena replicada ha sido -> " + cadenaReplicada);
                case 1 -> System.out.println("Numero de argumentos menor a 2");
                case 2 -> System.out.println("Otros casos");
            }


        }catch (IOException e){
            System.out.println("Error del tipo IOE");
        } catch (InterruptedException e) {
            System.out.println("Error en el wait For");
        }

    }
}
